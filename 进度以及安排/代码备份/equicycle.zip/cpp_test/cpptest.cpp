/*
 * @Author: Ashington ashington258@proton.me
 * @Date: 2024-07-23 11:08:19
 * @LastEditors: Ashington ashington258@proton.me
 * @LastEditTime: 2024-07-23 11:08:25
 * @FilePath: \equicycle\cpp_test\cpptest.cpp
 * @Description: 请填写简介
 * 联系方式:921488837@qq.com
 * Copyright (c) 2024 by ${git_name_email}, All Rights Reserved. 
 */
#include "cpptest.h"
#include <iostream>

void cpp_test_function(void)
{
    std::cout << "Hello from C++!" << std::endl;
}
