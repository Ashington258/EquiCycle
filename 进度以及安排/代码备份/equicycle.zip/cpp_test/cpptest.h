/*
 * @Author: Ashington ashington258@proton.me
 * @Date: 2024-07-23 11:08:26
 * @LastEditors: Ashington ashington258@proton.me
 * @LastEditTime: 2024-07-23 11:08:26
 * @FilePath: \equicycle\cpp_test\cpptest.h
 * @Description: 请填写简介
 * 联系方式:921488837@qq.com
 * Copyright (c) 2024 by ${git_name_email}, All Rights Reserved. 
 */
#ifndef CPPTEST_H
#define CPPTEST_H

#ifdef __cplusplus
extern "C" {
#endif

void cpp_test_function(void);

#ifdef __cplusplus
}
#endif

#endif // CPPTEST_H
