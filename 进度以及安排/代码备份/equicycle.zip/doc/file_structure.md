# 文件格式说明

这是一个不严谨的filetree，不带后缀表示文件夹，后期使用directory-tree规范化

.vscode/
api/
build/
cmake/
CMakeFiles/
Core/
doc/
Drivers/
control - 放置控制代码
    balance - 放置平衡代码
        balance_controller.cpp 
        balance_controller.h
.mxproject
build.ninja
CMakeCache.txt
CMakeLists.txt
CMakePresets.json
cmake_install.cmake
compile_commands.json
equicycle.ioc
startup_stm32h743xx.s
STM32H743VIHx_FLASH.ld